sub init()
    ' Intentionally empty: stub_hello has no per-scene logic.
end sub
'//# sourceMappingURL=./MainScene.brs.map