---
title: CreateObject
kind: global_function
tags: [construct]
---
# CreateObject

Constructs a component.
