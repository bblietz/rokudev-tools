sub init()
    m.paddleRect = m.top.findNode("paddleRect")
    m.top.observeField("paddleY", "onPaddleY")
end sub

sub onPaddleY()
    if m.top.side = "left" then
        sideX = 40
    else
        sideX = 1860
    end if
    m.paddleRect.translation = [
        sideX
        m.top.paddleY
    ]
end sub
'//# sourceMappingURL=./Paddle.brs.map