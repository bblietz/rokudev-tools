' Parse Roku Direct Publisher JSON into a ContentNode tree:
'   root
'     category[0] (title = category.name)
'       item[0]   (title, description, hdPosterUrl, stream)
'       item[1]
'       ...
'     category[1]
'
' Tolerant: missing optional fields are logged and skipped, never fatal.
function Feed_ParseRdpJson(jsonText as string) as object
    parsed = ParseJson(jsonText)
    root = CreateObject("roSGNode", "ContentNode")
    if parsed = invalid then
        return root
    end if
    categories = parsed.categories
    if categories = invalid or categories.Count() = 0 then
        ' Older RDP feeds expose a top-level "movies" array without categories.
        ' Bucket them under a single "All" category.
        movies = parsed.movies
        if movies <> invalid and movies.Count() > 0 then
            cat = root.CreateChild("ContentNode")
            cat.title = "All"
            Feed_AddItems(cat, movies)
        end if
        return root
    end if
    for each c in categories
        cat = root.CreateChild("ContentNode")
        cat.title = c.name
        if c.playlistName <> invalid then
            ' some RDP feeds key items by playlist name; assume flat for now.
            Feed_AddItems(cat, c.items)
        else if c.movies <> invalid then
            Feed_AddItems(cat, c.movies)
        end if
    end for
    return root
end function

sub Feed_AddItems(parent as object, items as object) as void
    if items = invalid then
        return
    end if
    for each it in items
        node = parent.CreateChild("ContentNode")
        node.title = Feed_StringOr(it.title, "")
        node.description = Feed_StringOr(it.longDescription, Feed_StringOr(it.shortDescription, ""))
        node.hdPosterUrl = Feed_StringOr(it.thumbnail, "")
        if it.content <> invalid and it.content.videos <> invalid and it.content.videos.Count() > 0 then
            v = it.content.videos[0]
            node.stream = Feed_StringOr(v.url, "")
            node.streamFormat = Feed_StringOr(v.videoType, "mp4")
        end if
    end for
end sub

function Feed_StringOr(v as dynamic, def as string) as string
    if v = invalid then
        return def
    end if
    if Type(v) <> "roString" and Type(v) <> "String" then
        return def
    end if
    return v
end function
'//# sourceMappingURL=./Feed.brs.map