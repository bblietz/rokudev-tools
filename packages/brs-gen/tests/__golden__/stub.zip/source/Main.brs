sub Main(args as dynamic) as void
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.CreateScene("MainScene")
    screen.show()
    ' Invoke brs-gen-generated module init hooks.
    Modules_OnMainBeforeSceneShow(args)
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then
                exit while
            end if
        end if
    end while
end sub
'//# sourceMappingURL=./Main.brs.map