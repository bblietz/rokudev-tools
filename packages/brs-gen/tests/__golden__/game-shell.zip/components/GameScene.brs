sub init()
    ' Read config from TemplateConfig() (defaults applied via Plan 4e schema-strict downstream).
    cfg = TemplateConfig()
    m.top.cpuDifficulty = cfg.cpu_difficulty
    m.top.scoreToWin = cfg.score_to_win.toInt()
    m.top.highScorePersistence = (cfg.high_score_persistence = "true")
    ' Cache child node refs.
    m.playerPaddle = m.top.findNode("playerPaddle")
    m.cpuPaddle = m.top.findNode("cpuPaddle")
    m.ball = m.top.findNode("ball")
    m.playerScoreLabel = m.top.findNode("playerScore")
    m.cpuScoreLabel = m.top.findNode("cpuScore")
    m.titleGroup = m.top.findNode("titleGroup")
    m.titleHigh = m.top.findNode("titleHigh")
    m.gameOverGroup = m.top.findNode("gameOverGroup")
    m.tick = m.top.findNode("tick")
    ' Internal state.
    m.state = "title"
    m.playerScore = 0
    m.cpuScore = 0
    m.upHeld = false
    m.downHeld = false
    m.servesPlayed = 0
    m.cpuLagPx = Pong_DifficultyToLagPx(m.top.cpuDifficulty)
    ' High score: read from registry if persistence enabled.
    m.highScore = 0
    if m.top.highScorePersistence then
        reg = CreateObject("roRegistrySection", "GameShell")
        if reg.exists("highScore") then
            m.highScore = val(reg.read("highScore"), 10)
        end if
    end if
    ' Wire timer + key handler.
    m.tick.observeField("fire", "onTick")
    ' Explicit Scene-root focus: with no focusable child (no PosterGrid /
    ' Button) the default focus is unreliable on some Roku firmwares; this
    ' guarantees onKeyEvent receives D-pad input.
    m.top.setFocus(true)
    ' Enter title (idempotent).
    enterTitle()
    ' Fire after_scene_show ONCE on boot, AFTER first enterTitle. Matches
    ' Plan 4d's NowPlayingScene/after_scene_show-from-init pattern.
    Modules_OnGameSceneAfterSceneShow(m)
end sub

sub enterTitle()
    m.tick.control = "stop"
    m.playerScore = 0
    m.cpuScore = 0
    m.playerScoreLabel.text = "0"
    m.cpuScoreLabel.text = "0"
    m.playerPaddle.paddleY = 470
    m.cpuPaddle.paddleY = 470
    m.ball.ballX = 948
    m.ball.ballY = 528
    m.ball.vx = 0
    m.ball.vy = 0
    m.titleHigh.text = "High score: " + m.highScore.toStr()
    m.titleGroup.visible = true
    m.gameOverGroup.visible = false
    m.state = "title"
end sub

sub enterPlaying()
    m.titleGroup.visible = false
    m.gameOverGroup.visible = false
    ' Center the ball; choose serve direction by parity of m.servesPlayed.
    m.ball.ballX = 948
    m.ball.ballY = 528
    if (m.servesPlayed mod 2) = 0 then
        m.ball.vx = -9.0 ' toward player (left)
    else
        m.ball.vx = 9.0 ' toward CPU (right)
    end if
    m.ball.vy = 4.5
    m.servesPlayed = m.servesPlayed + 1
    m.tick.control = "start"
    m.state = "playing"
    Modules_OnGameSceneAfterGameStart(m)
end sub

sub enterGameOver()
    m.tick.control = "stop"
    m.titleGroup.visible = false
    m.gameOverGroup.visible = true
    if m.top.highScorePersistence and m.playerScore > m.highScore then
        m.highScore = m.playerScore
        reg = CreateObject("roRegistrySection", "GameShell")
        reg.write("highScore", m.highScore.toStr())
        reg.flush()
    end if
    m.state = "gameover"
    Modules_OnGameSceneAfterGameOver(m)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    ' Roku firmware variation: ECP "Select" maps to key="OK" on most platforms
    ' but key="select" (lowercase) on Roku TV Native (per music_player/news_channel
    ' precedent). Accept either to be firmware-agnostic.
    if m.state = "title" then
        if (key = "OK" or key = "select") and press then
            enterPlaying()
            return true
        end if
        return false ' Back falls through to Roku channel-exit
    end if
    if m.state = "playing" then
        if key = "up" then
            m.upHeld = press
            return true
        end if
        if key = "down" then
            m.downHeld = press
            return true
        end if
        if key = "back" and press then
            enterTitle()
            return true
        end if
        return false
    end if
    if m.state = "gameover" then
        if (key = "OK" or key = "select" or key = "back") and press then
            enterTitle()
            return true
        end if
        return false
    end if
    return false
end function

sub onTick()
    if m.state <> "playing" then
        return
    end if ' state-guard against late Timer events
    ' Player paddle.
    if m.upHeld then
        m.playerPaddle.paddleY = m.playerPaddle.paddleY - 12
    end if
    if m.downHeld then
        m.playerPaddle.paddleY = m.playerPaddle.paddleY + 12
    end if
    if m.playerPaddle.paddleY < 0 then
        m.playerPaddle.paddleY = 0
    end if
    maxPaddleY = 1080 - 140
    if m.playerPaddle.paddleY > maxPaddleY then
        m.playerPaddle.paddleY = maxPaddleY
    end if
    ' CPU paddle.
    m.cpuPaddle.paddleY = Pong_StepCpu(m.cpuPaddle.paddleY, m.ball.ballY, m.cpuLagPx)
    ' Ball step + score detection. NB: `step` is a BrightScript reserved word
    ' (per project MEMORY); use `b` for the returned associative array.
    b = Pong_StepBall(m.ball.ballX, m.ball.ballY, m.ball.vx, m.ball.vy)
    m.ball.ballX = b.ballX
    m.ball.ballY = b.ballY
    ' Wall collision.
    m.ball.vy = Pong_CollideWall(m.ball.ballY, m.ball.vy, 1080)
    ' Paddle collisions (player on left, CPU on right).
    cp = Pong_CollidePaddle(m.ball.ballX, m.ball.ballY, m.ball.vx, m.ball.vy, 40, m.playerPaddle.paddleY)
    m.ball.vx = cp.vx
    m.ball.vy = cp.vy
    cc = Pong_CollidePaddle(m.ball.ballX, m.ball.ballY, m.ball.vx, m.ball.vy, 1860, m.cpuPaddle.paddleY)
    m.ball.vx = cc.vx
    m.ball.vy = cc.vy
    ' Score handling.
    if b.scored = "cpu" then
        m.playerScore = m.playerScore + 1
        m.playerScoreLabel.text = m.playerScore.toStr()
        if m.playerScore >= m.top.scoreToWin then
            enterGameOver()
        else
            ' Re-serve.
            m.ball.ballX = 948
            m.ball.ballY = 528
            m.ball.vx = 9.0 ' serve toward CPU again
            m.ball.vy = 4.5
        end if
    end if
    if b.scored = "player" then
        m.cpuScore = m.cpuScore + 1
        m.cpuScoreLabel.text = m.cpuScore.toStr()
        if m.cpuScore >= m.top.scoreToWin then
            enterGameOver()
        else
            m.ball.ballX = 948
            m.ball.ballY = 528
            m.ball.vx = -9.0 ' serve toward player
            m.ball.vy = 4.5
        end if
    end if
end sub
'//# sourceMappingURL=./GameScene.brs.map