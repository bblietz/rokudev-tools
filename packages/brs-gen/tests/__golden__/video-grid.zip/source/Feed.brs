' Parse Roku Direct Publisher JSON into a ContentNode tree:
'   root
'     category[0] (title = category.name)
'       item[0]   (title, description, hdPosterUrl, stream)
'       item[1]
'       ...
'     category[1]
'
' Tolerant: missing optional fields are logged and skipped, never fatal.
function Feed_ParseRdpJson(jsonText as dynamic) as object
    ' Parameter is `as dynamic` (not `as string`) so callers can pass invalid
    ' or non-string values without triggering a runtime cast error. We guard
    ' explicitly below.
    root = CreateObject("roSGNode", "ContentNode")
    if jsonText = invalid then
        return root
    end if
    if Type(jsonText) <> "roString" and Type(jsonText) <> "String" then
        return root
    end if
    parsed = ParseJson(jsonText)
    if parsed = invalid then
        return root
    end if
    ' Prefer top-level `movies` array when present. AVideo, Roku Direct Publisher
    ' v2, and most modern RDP feeds emit movies at the top level alongside
    ' optional `categories` metadata (which often references playlists by name
    ' rather than embedding items inline). We bucket the flat movies under a
    ' single "All" category for v0.4. A future module/template will consume
    ' the categories+playlists structure for category-aware row labels.
    movies = parsed.movies
    if movies <> invalid and movies.Count() > 0 then
        cat = root.CreateChild("ContentNode")
        cat.title = "All"
        Feed_AddItems(cat, movies)
        return root
    end if
    ' Fallback: older RDP feeds embed items directly under each category.
    categories = parsed.categories
    if categories <> invalid and categories.Count() > 0 then
        for each c in categories
            cat = root.CreateChild("ContentNode")
            cat.title = c.name
            if c.movies <> invalid then
                Feed_AddItems(cat, c.movies)
            else if c.items <> invalid then
                Feed_AddItems(cat, c.items)
            end if
        end for
    end if
    return root
end function

sub Feed_AddItems(parent as dynamic, items as dynamic) as void
    if items = invalid then
        return
    end if
    for each it in items
        node = parent.CreateChild("ContentNode")
        node.title = Feed_StringOr(it.title, "")
        desc = Feed_StringOr(it.longDescription, Feed_StringOr(it.shortDescription, ""))
        ' Avoid noisy duplication when the feed copies the title into the long
        ' description (AVideo demo does this). Leave description empty so the
        ' HeroUnit only shows the title.
        if desc = node.title then
            desc = ""
        end if
        node.description = desc
        node.hdPosterUrl = Feed_StringOr(it.thumbnail, "")
        ' RDP-spec items expose stream URLs via content.videos[0].url. Items
        ' missing this shape (e.g. AVideo's roku.json sample) end up with no
        ' playable URL on the node and PlayerScene shows the "no stream" overlay
        ' rather than crashing. The node still renders fine in the row list.
        if it.content <> invalid and it.content.videos <> invalid and it.content.videos.Count() > 0 then
            v = it.content.videos[0]
            streamUrl = Feed_StringOr(v.url, "")
            if streamUrl <> "" then
                ' ContentNode does not expose a `stream` field directly. PlayerScene
                ' wraps the item in a parent ContentNode with the URL set on a child
                ' (see PlayerScene.bs startPlayback). We stash the URL + format here
                ' under a custom field name that PlayerScene reads.
                node.url = streamUrl
                node.streamFormat = Feed_StringOr(v.videoType, "mp4")
            end if
        end if
    end for
end sub

function Feed_StringOr(v as dynamic, def as string) as string
    if v = invalid then
        return def
    end if
    if Type(v) <> "roString" and Type(v) <> "String" then
        return def
    end if
    return v
end function
'//# sourceMappingURL=./Feed.brs.map