' music_player Main.bs
'
' SceneGraph entry point. Constructs the screen + Scene, fires the
' Main/before_scene_show init hook, and shows the scene.
sub Main(args as dynamic)
    screen = createObject("roSGScreen")
    port = createObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.createScene("MainScene")
    Modules_OnMainBeforeSceneShow(args)
    screen.show()
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then
                return
            end if
        end if
    end while
end sub
'//# sourceMappingURL=./Main.brs.map