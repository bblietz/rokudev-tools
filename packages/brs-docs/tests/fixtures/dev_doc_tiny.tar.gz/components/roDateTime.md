---
title: roDateTime
kind: component
tags: [datetime, time, epoch]
---
# roDateTime

A date/time component.

## Interfaces
- ifDateTime
