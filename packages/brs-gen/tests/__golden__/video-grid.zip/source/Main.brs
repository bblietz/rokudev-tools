' Entry point for the video_grid_channel template.
sub Main(args as dynamic) as void
    ' Merger-emitted init dispatch: fires "before_scene_show" hooks.
    Modules_OnMainBeforeSceneShow(args)
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.SetMessagePort(m.port)
    scene = screen.CreateScene("MainScene")
    screen.Show()
    while true
        msg = Wait(0, m.port)
        msgType = Type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then
                return
            end if
        end if
    end while
end sub
'//# sourceMappingURL=./Main.brs.map