sub init()
    Modules_OnMainSceneAfterSceneShow(m)
end sub
'//# sourceMappingURL=./MainScene.brs.map