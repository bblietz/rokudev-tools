sub init()
    m.hero = m.top.findNode("hero")
    m.rowList = m.top.findNode("rowList")
    m.rotateTimer = m.top.findNode("rotateTimer")
    m.loadingLabel = m.top.findNode("loadingLabel")
    m.errorLabel = m.top.findNode("errorLabel")
    m.detailsRef = invalid
    ' Fire module-opt hook before any content load.
    Modules_OnMainSceneBeforeContentLoad(m)
    ' Kick feed fetch. "Loading..." stays visible until the row binds.
    m.feedTask = CreateObject("roSGNode", "HttpTask")
    m.feedTask.observeField("state", "onFeedState")
    m.feedTask.url = TemplateConfig().feed_url
    m.feedTask.control = "run"
end sub

sub onFeedState()
    if m.feedTask.state <> "stop" then
        return
    end if
    if m.feedTask.error <> invalid and m.feedTask.error <> "" then
        m.loadingLabel.visible = false
        m.errorLabel.text = "Feed load failed: " + m.feedTask.error
        m.errorLabel.visible = true
        return
    end if
    root = Feed_ParseRdpJson(m.feedTask.result)
    m.rowList.content = root
    Modules_OnMainSceneAfterContentLoad(m)
    ' Seed hero with the first item of the first category.
    if root.getChildCount() > 0 then
        firstRow = root.getChild(0)
        if firstRow.getChildCount() > 0 then
            m.hero.content = firstRow.getChild(0)
            Modules_OnMainSceneAfterHeroLoad(m)
        end if
    end if
    ' Hide the loading label now that the row is bound.
    m.loadingLabel.visible = false
    ' Start auto-rotation.
    m.rotateTimer.observeField("fire", "onRotateTick")
    m.rotateTimer.control = "start"
    m.heroIdx = 0
    m.rowList.observeField("rowItemSelected", "onItemSelected")
    ' Bind focus to the rowList so Up/Down/Left/Right move through tiles.
    m.rowList.setFocus(true)
end sub

sub onRotateTick()
    root = m.rowList.content
    if root = invalid or root.getChildCount() = 0 then
        return
    end if
    firstRow = root.getChild(0)
    n = firstRow.getChildCount()
    if n = 0 then
        return
    end if
    m.heroIdx = (m.heroIdx + 1) mod n
    m.hero.content = firstRow.getChild(m.heroIdx)
end sub

sub onItemSelected()
    idx = m.rowList.rowItemSelected
    rowIdx = idx[0]
    itemIdx = idx[1]
    row = m.rowList.content.getChild(rowIdx)
    item = row.getChild(itemIdx)
    ' Cache the created node so onDetailsClose can remove the correct
    ' instance. findNode searches by `id`, not by component type, and
    ' createChild does not set an id; without this ref the overlay would
    ' leak on every Back press.
    details = m.top.createChild("DetailsScene")
    details.observeField("close", "onDetailsClose")
    details.content = item
    details.setFocus(true)
    m.detailsRef = details
end sub

sub onDetailsClose()
    if m.detailsRef <> invalid then
        m.top.removeChild(m.detailsRef)
        m.detailsRef = invalid
    end if
    m.rowList.setFocus(true)
end sub
'//# sourceMappingURL=./MainScene.brs.map