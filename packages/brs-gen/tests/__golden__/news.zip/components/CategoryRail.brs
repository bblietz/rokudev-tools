sub init()
    m.list = m.top.findNode("list")
end sub

sub onContentChange()
    c = m.top.content
    if c = invalid then
        return
    end if
    m.list.content = c
end sub
'//# sourceMappingURL=./CategoryRail.brs.map