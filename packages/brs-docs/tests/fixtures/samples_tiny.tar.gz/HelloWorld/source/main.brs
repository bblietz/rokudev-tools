' Hello-world Roku channel
sub main()
    print "hello"
end sub
