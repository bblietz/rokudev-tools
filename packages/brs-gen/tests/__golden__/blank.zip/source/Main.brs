sub Main()
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)
    ' CreateScene attaches the MainScene as the screen's root and returns a
    ' handle. The intentionally-unused `scene` binding makes the idiom
    ' explicit: creation is the side effect that matters.
    scene = screen.CreateScene("MainScene")
    screen.show()
    while true
        msg = wait(0, m.port)
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed() then
            return
        end if
    end while
end sub
'//# sourceMappingURL=./Main.brs.map